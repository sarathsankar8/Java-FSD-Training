function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username == "admin" && password == "12345")
{
window.location = "main.html";
return false;
}
else if(username!="admin" && password!="12345")
{
    alert("Invalid username and password");
    return false;
}
else if(username!="admin"){
    alert("Invalid username");
    return false;
}
else{
    alert("Invalid password");
    return false;
}
}


// api url
const api_url = 
      "https://jsonplaceholder.typicode.com/todos";
  
// Defining async function
async function getapi(url) {
    
    // Storing response
    const response = await fetch(url);
    
    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);
    if (response) {
        hideloader();
    }
    show(data);
}
// Calling that async function
getapi(api_url);
  

// Function to define innerHTML for HTML table
//function show(data) {
  
    
    // Loop to access all rows 
    /*for (let r of data.list) {
        tab += `<tr> 
    <td>${r.name} </td>
    <td>${r.office}</td>
    <td>${r.position}</td> 
    <td>${r.salary}</td>          
</tr>`;
    }
    // Setting innerHTML as tab variable
    document.getElementById("employees").innerHTML = tab;
}*/